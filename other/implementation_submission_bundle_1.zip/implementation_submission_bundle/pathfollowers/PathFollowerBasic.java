package pathfollowers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;

import com.badlogic.gdx.math.Vector2;
import mycontroller.Move;
import mycontroller.MyAIController;
import mycontroller.Sensor;
import utilities.Coordinate;
import utilities.PeekTuple;
import world.WorldSpatial;

public class PathFollowerBasic implements IPathFollower {


    private MyAIController controller;
    private Sensor sensor;
    private final Double MAX_SPEED = 2.0;
    private final Double TURN_SPEED = 1.5;
    private Move.SpeedChange desiredSpeedChange;
    private LinkedList<Move> previousMoves;
    private Boolean escaping;
    private Integer durationOfEscapeMove;
    private final Integer TRACKED_MOVES = 30;
    private final Integer CORRECTING_MOVES = 15;
    private Integer lastHealth;
    private Move escapeMove;

    public PathFollowerBasic(MyAIController controller, Sensor sensor) {
        this.controller = controller;
        this.sensor = sensor;
        previousMoves = new LinkedList<Move>();
        lastHealth = sensor.getHealth();
        escaping = false;
    }

    // Note: PathFinder is the collision-avoidance guide, we don't need to do that here.
    @Override
    public void update(float delta, ArrayList<Coordinate> coordsToFollow) {
        Coordinate coord = null;

        // If no coordinate given, this is an error!
        if (coordsToFollow.isEmpty()) {
            System.out.println("Error: No coordinate given to PathFollower by the PathFinder.");
        }
        // Otherwise, proceed
        else {
            coord = coordsToFollow.get(0);
            float tarDegree = (float) getDegreeOfCoord(coord);

            System.out.println("Coordinate given = (" + coord.x + ", " + coord.y + ").");
            System.out.println("Coordinate of car = (" + sensor.getPosition().x + ", " + sensor.getPosition().y + ").");
            System.out.println("Direction Facing = " + sensor.getOrientation());
            System.out.println("Angle of Car = " + sensor.getAngle());

            // Remove out-dated moves
            if (previousMoves.size() > TRACKED_MOVES) { previousMoves.poll(); }
            // Alternate Update Method if escaping
            if (escaping) {
                updateEscape(delta, coord, tarDegree);
                return;
            }

            // If directed to do so, go straight
            WorldSpatial.RelativeDirection tarDirection = getDirection(tarDegree);
            if (tarDirection == WorldSpatial.RelativeDirection.FORWARD ||
                    tarDirection == WorldSpatial.RelativeDirection.BACKWARD) {
                goForwardOrBackward(tarDirection, adjustVelocity(coord));
            }

            else {
                // Generate All combinations of acceleration, reverse acceleration, Left and Right turns
                Vector2 currVelocity = sensor.getVelocity2();
                Vector2[] testSpeeds = getTestSpeeds(currVelocity);
                Move.SpeedChange[] speedChanges = getSpeedChanges(testSpeeds, currVelocity);
                WorldSpatial.RelativeDirection[] testDirections = {WorldSpatial.RelativeDirection.LEFT,
                        WorldSpatial.RelativeDirection.RIGHT};

                // Find the best direction and the index of the best change in velocity to reach the destination
                WorldSpatial.RelativeDirection bestDirection = null;
                int bestSpeedInd = 0;
                float minDist = Float.MAX_VALUE;
                for (int speed = 0; speed < 3; speed++) {
                    for (int d = 0; d < 2; d++) {

                        // Use controller.peek(...) to determine best combination to reach target coordinate
                        PeekTuple approxDest = controller.peek(testSpeeds[speed], tarDegree, testDirections[d], delta);
                        Coordinate approxCoord = approxDest.getCoordinate();
                        float projectedDistanceFromTarget = coord.distanceFrom(approxCoord);
                        System.out.println("----\nProjected Distance: " + projectedDistanceFromTarget);
                        System.out.println("Direction = " + testDirections[d] + ". Speed = " + testSpeeds[speed].len() + "----\n");
                        if (approxDest.getReachable() && projectedDistanceFromTarget < minDist) {
                            minDist = coord.distanceFrom(approxCoord);
                            bestDirection = testDirections[d];
                            bestSpeedInd = speed;
                        }
                    }
                }
                moveCar(currVelocity.len(), testSpeeds[bestSpeedInd].len(), delta, bestDirection);

                // Update Queue of Last Moves
                previousMoves.offer(new Move(sensor.getPosition(), coord, sensor.getAngle(), speedChanges[bestSpeedInd],
                        bestDirection));
            }
        }
    }

    private void updateEscape(float delta, Coordinate coord, float tarDegree) {

        // If we're escaping and reach a point where all of the previous moves were the same, only move forward!
        if (escaping && allSame(previousMoves)) {
            moveOnlyForward(escapeMove, delta, coord);
            return;
        }

        // Stop escaping once we are facing our goal
        if (tarDegree == sensor.getAngle()) {
            escaping = false;
            escapeMove = null;
        }


        // If the last few moves were all the same, start making moves to correct our course.
        if (allSame(previousMoves) && sensor.getHealth() < lastHealth && previousMoves.size() > 0) {
            escaping = true;
            escapeMove = previousMoves.peek().getOppositeMove();
        }

        // Initial and after-initial escape moves
        if (escaping) {
            System.out.println("Escaping!");
            moveCar(escapeMove, delta, coord);
        }
    }



    private Boolean allSame(LinkedList<Move> previousMoves) {
        LinkedList<Move> moves = new LinkedList<Move>(previousMoves);
        Move lastMove = moves.poll();
        Move thisMove;
        do {
            thisMove = moves.poll();
            if (thisMove == null || lastMove == null || !lastMove.equals(thisMove)) {
                return false;
            }
        } while (!moves.isEmpty());
        return true;
    }

    private void moveOnlyForward(Move move, float delta, Coordinate targetCoord) {
        Move.SpeedChange speedChange;
        WorldSpatial.RelativeDirection direction = WorldSpatial.RelativeDirection.FORWARD;
        if (escapeMove.getSpeedChange() == Move.SpeedChange.ACCELERATE) {
            controller.applyForwardAcceleration();
            speedChange =  Move.SpeedChange.ACCELERATE;
        }
        else {
            controller.applyReverseAcceleration();
            speedChange =  Move.SpeedChange.SLOWDOWN;
        }
        lastHealth = sensor.getHealth();
        previousMoves.offer(new Move(sensor.getPosition(), targetCoord, sensor.getAngle(), speedChange, direction));
    }


    private void moveCar(Move escapeMove, float delta, Coordinate targetCoordinate ) {
        Move.SpeedChange speedChange;
        WorldSpatial.RelativeDirection direction;

        if (escapeMove.getSpeedChange() == Move.SpeedChange.ACCELERATE) {
            controller.applyForwardAcceleration();
            speedChange =  Move.SpeedChange.ACCELERATE;
        }
        else {
            controller.applyReverseAcceleration();
            speedChange =  Move.SpeedChange.SLOWDOWN;
        }
        if (escapeMove.getTurnDirection() == WorldSpatial.RelativeDirection.RIGHT) {
            controller.turnRight(delta);
            direction = WorldSpatial.RelativeDirection.RIGHT;
        }
        else {
            controller.turnLeft(delta);
            direction = WorldSpatial.RelativeDirection.LEFT;
        }
        lastHealth = sensor.getHealth();
        previousMoves.offer(new Move(sensor.getPosition(), targetCoordinate, sensor.getAngle(), speedChange, direction));
    }

    private void moveCar(float currentVelocity, float desiredVelocity, float delta,
                         WorldSpatial.RelativeDirection bestDirection) {
        if (currentVelocity < desiredVelocity) {
            System.out.println("Applying Forward Acceleration");
            controller.applyForwardAcceleration();
        } else {
            System.out.println("Applying Reverse Acceleration");
            controller.applyReverseAcceleration();
        }
        if (bestDirection == WorldSpatial.RelativeDirection.RIGHT) {
            System.out.println("Turning Right");
            controller.turnRight(delta);
        } else {
            System.out.println("Turning Left");
            controller.turnLeft(delta);
        }
        lastHealth = sensor.getHealth();
    }


    private Vector2[] getTestSpeeds(Vector2 currVelocity) {
        float addedX = (Double.compare(currVelocity.x, 0.0) == 0 ?  (float) .001 : 0 );
        float addedY = (Double.compare(currVelocity.y, 0.0) == 0 ?  (float) .001 : 0 );
        Vector2[] testSpeeds = {
                new Vector2(currVelocity.x * (float) 1.1 + addedX, currVelocity.y * (float) 1.1 + addedY),
                new Vector2(currVelocity.x * (float) 1.05 + addedX, currVelocity.y * (float) 1.05 + addedY),
                new Vector2(currVelocity.x * (float) 0.95 + addedX, currVelocity.y * (float) 0.95 + addedY),
                new Vector2(currVelocity.x * (float) 0.9 + addedX, currVelocity.y * (float) 0.9 + addedY)};

        return testSpeeds;
    }

    private Move.SpeedChange[] getSpeedChanges(Vector2[] testSpeeds, Vector2 currVelocity) {

        float currentSpeed = currVelocity.len();
        Move.SpeedChange[] speedChanges = new Move.SpeedChange[testSpeeds.length];
        for (int i = 0; i < testSpeeds.length; i++) {
            if (testSpeeds[i].len() < currentSpeed) {
                speedChanges[i] = Move.SpeedChange.SLOWDOWN;
            }
            else {
                speedChanges[i] = Move.SpeedChange.ACCELERATE;
            }
        }
        return speedChanges;
    }



    private void goForwardOrBackward(WorldSpatial.RelativeDirection d, Move.SpeedChange speedChange) {
        if (d == WorldSpatial.RelativeDirection.FORWARD) {
            if (speedChange == Move.SpeedChange.ACCELERATE) {
                controller.applyForwardAcceleration();
            } else if (speedChange == Move.SpeedChange.SLOWDOWN) {
                controller.applyReverseAcceleration();
            }
        } else if (d == WorldSpatial.RelativeDirection.BACKWARD) {
            if (speedChange == Move.SpeedChange.ACCELERATE) {
                controller.applyReverseAcceleration();
            } else if (speedChange == Move.SpeedChange.SLOWDOWN) {
                controller.applyForwardAcceleration();
            }
        }
        lastHealth = sensor.getHealth();
    }


    private Move.SpeedChange adjustVelocity(Coordinate coordinate) {
        Coordinate carPosition = sensor.getPosition();
        // If the PathFinder is telling us to slow down, or if we're above the max speed, slow down!
        if (coordinate.distanceFrom(carPosition) <= sensor.VISION_AHEAD / 3 || sensor.getVelocity() > MAX_SPEED) {
            return Move.SpeedChange.SLOWDOWN;
        }
        // If the PathFinder is happy with our acceleration, or we're at max speed, maintain current speed
        else if (coordinate.distanceFrom(carPosition) < sensor.VISION_AHEAD || sensor.getVelocity() == MAX_SPEED) {
            return Move.SpeedChange.MAINTAIN;
        }
        // If the PathFinder is saying to go to the coordinate at or beyond the edge of our visual map & we're below
        // max speed, Accelerate!
        else {
            return Move.SpeedChange.ACCELERATE;
        }
    }


    // Get the degree of the Coordinate
    private double getDegreeOfCoord(Coordinate coord) {

        // Calculate the deltas as the next minus the current
        double delta_x = (double) coord.x - (double) sensor.getX();
        double delta_y = (double) coord.y - (double) sensor.getY();

        // Calculate the angle in radians using atan2
        double theta = Math.atan2(delta_y, delta_x);

        // Calculate the angle in degrees (coordinate from the east, 0 degrees; 270 is given as -90, 225 as -135, etc.)
        double angle = theta * 180 / Math.PI;


        // If angle is negative, make it positive (e.g. -90 to 270)
        if (Double.compare(angle, 0.0) < 0) {
            angle += 360.0;
        }
        return angle;
    }


    // Given our direction, what is the direction of the target coordinate?
    private WorldSpatial.RelativeDirection getDirection(double degree) {

        double tarAngle = degree;
        double carAngle = sensor.getAngle();

        if (tarAngle - carAngle == 0) {
            return WorldSpatial.RelativeDirection.FORWARD;
        } else if (tarAngle + 180 == carAngle ||
                tarAngle - 180 == carAngle) {
            return WorldSpatial.RelativeDirection.BACKWARD;
        } else if (Math.abs(carAngle - tarAngle) < 180) {
            if (carAngle < tarAngle) {
                return WorldSpatial.RelativeDirection.LEFT;
            } else {
                return WorldSpatial.RelativeDirection.RIGHT;
            }
        } else {
            if (carAngle < tarAngle) {
                return WorldSpatial.RelativeDirection.RIGHT;
            } else {
                return WorldSpatial.RelativeDirection.LEFT;
            }
        }
    }


//    private void turnToCoord(Coordinate coord) {
//
//        // Turn in Relative direction of the coordinate in relation to the current direction of the car
//        if (coordIsLeft(coord)) {
//            controller.turnLeft(delta);
//        }
//        else if (coord.IsRight(coord)) {
//            controller.turnRight(delta);
//        }
//
//        else if (coord.isDirectlyBehind(coord)) {
//            controller.applyReverseAcceleration();
//        }
//
//    }


    // Set a null Best Turn Direction and a Best Acceleration / Deacceleration
    // Generate diff PeekTuples using controller.peek(...) w/ different Velocities and diff Left & Right turn
    // directions, keeping track of the best combination of turn direction and acceleration / ReverseAcceleration
    // Just generate a list of 4 options: Accel+Left, Accel+Right, ReverseAccel+Left, ReverseAccel+Right?
    // Find Best Turn Direction and a Best Acceleration / Deacceleration


    // Old Proposed Strategies
    // Create a PriorityQueue of PeekTuples based on proximity of PeekTuple to Coordinate

    // get turn direction
    // getTurnDirection(coord);
    // get target speed
    // Get speed adjustment required
    // Apply turn and acceleration
    // Turn in Relative direction of the coordinate in relation to the current direction of the car
    // turnToCoord(coord);

    // If coord is far, accelerate
    // If the coord is close, deaccelerate
    // If

}